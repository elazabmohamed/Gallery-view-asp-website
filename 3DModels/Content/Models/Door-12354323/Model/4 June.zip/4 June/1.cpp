#include<iostream>
#include<fstream>
#include <vector>
#include "calisan.h"
#include "tamZamanli.h"
#include "yariZamanli.h"
using namespace std;
int main(){
	calisan calisan1();
	vector<tamZamanli> tamCalisan(5);
	vector<yariZamanli> yariCalisan(5);
	char secenek;
	cout<<"************Menu**************"<<endl;
	cout<<"Tam zamanli personle eklemek icin T tuslayiniz:\nYari zamanli personel eklemek icin Y tuslayiniz:\nTam zamanli kaiytlari listelemek icin K tuslayiniz:\nYari zamanli kaiytlari listelemek icin K tuslayiniz:"<<endl;
	cin>>secenek;

	switch(secenek) {
	case 'T':
	string ad;
	string soyad;
	string telefonNumarasi;
	string eposta;
	string kimlikNo; 	
	 cout<<"Personel adi giriniz:\n";
	 cout<<"Personel soyadini giriniz:\n";
	 cout<<"Personel telefon numarasini giriniz:\n";
	 cout<<"Personel eposta adresini giriniz:\n"<<endl;
	 tamCalisan(1).tamZamanli(string ad,string soyad, string telefonNumarasi, string eposta, string kimlikNo);
	 tamCalisan.push_back(tamCalisan);
		break;
	case 'Y':
	string ad;
	string soyad;
	string telefonNumarasi;
	string eposta;
	string kimlikNo; 	
	 cout<<"Personel adi giriniz:\n";
	 cout<<"Personel soyadini giriniz:\n";
	 cout<<"Personel telefon numarasini giriniz:\n";
	 cout<<"Personel eposta adresini giriniz:\n"<<endl;
	 yariCalisan.tamZamanli(string ad,string soyad, string telefonNumarasi, string eposta, string kimlikNo);
	 yariCalisan.push_back(tamCalisan);
	    break;
	  case 'K':
	  
	    break;
	  case 'L':

	    break;
	  default:
	    cout<<"T, Y, K, L tuslarindan birini secmeniz lazim."<<endl;
	    ;
	}
	
	
	
	
	
	
	
	
	
	ofstream dosyaIslemleri ("dosyaIslemleri.txt");

	dosyaIslemleri.close();
	return 0;
}
