#include<iostream>
#include <vector>
//#include "calisan.h"
class yariZamanli:public calisan{
	private:
	string calistigiGun;
	public: 
	yariZamanli(string Ad,string Soyad, string TelefonNumarasi, string Eposta, string KimlikNo, string CalistigiGun){
	ad=Ad;
	soyad=Soyad;
	telefonNumarasi=TelefonNumarasi;
	eposta=Eposta;
	kimlikNo=KimlikNo;
	calistigiGun=CalistigiGun;
	}
	string getAd(){return ad;}
	string getSoyad(){return soyad;}
	string TelefonNumarasi(){return telefonNumarasi;}
	string getEposta(){return kimlikNo;}
	string getCalistigiGun(){return calistigiGun;}
};
