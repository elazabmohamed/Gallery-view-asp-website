#include<iostream>
#include <vector>
using namespace std;
class calisan{
	public: calisan(){};
	protected:
	string ad;
	string soyad;
	string telefonNumarasi;
	string eposta;
	string kimlikNo;	
};

