#include<iostream>
#include <vector>
//#include "calisan.h"
class tamZamanli:public calisan{
	public: 
	tamZamanli(	string Ad,string Soyad, string TelefonNumarasi, string Eposta, string KimlikNo){
	ad=Ad;
	soyad=Soyad;
	telefonNumarasi=TelefonNumarasi;
	eposta=Eposta;
	kimlikNo=KimlikNo;
	}
	string getAd(){return ad;}
	string getSoyad(){return soyad;}
	string TelefonNumarasi(){return telefonNumarasi;}
	string getEposta(){return kimlikNo;}
};
